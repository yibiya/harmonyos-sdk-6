export default {
  onCreate() {
    console.info('AceApplication onCreate');
  },
  onDestroy() {
    console.info('AceApplication onDestroy');
  }
}
