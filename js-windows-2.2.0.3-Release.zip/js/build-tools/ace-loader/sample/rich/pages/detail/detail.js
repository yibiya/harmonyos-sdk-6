import router from '@system.router'

export default {
  data: {
  },
  launch: function() {
    router.push ({
        uri:'pages/index/index',
    })
  }
}
