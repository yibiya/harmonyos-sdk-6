export default {
  data: {
    title: 'World'
  }
}
